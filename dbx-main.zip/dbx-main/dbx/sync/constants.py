from dbx.constants import DBX_PATH

DBX_SYNC_DIR = DBX_PATH / "sync"
