# :material-file-document-multiple-outline: CLI Reference

This page provides reference documentation for the CLI commands.

Please note that docs on this page are :material-robot: automatically generated from the CLI,
so it may have some cracks in terms of :material-format-font: formatting.

::: mkdocs-click
    :module: dbx.cli
    :command: click_app
    :depth: 1
