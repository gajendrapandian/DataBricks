# DB Normalizer

DB Normalizer is a relational database normalizer tool that allow database designers to perform automatic database schemas normalization quickly and accurately.

###### Project Requirements:
- Phyton 3.4
- PostgreSQL
- Py-postgreSQL
- psycopg2 2.5.4
